package crypto;

import com.example.doprava_bp.ObuParameters;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class CryptoCore{
    ObuParameters obuParameters;
    Cryptogram userCryptogram;
    Cryptogram receiverCryptogram;

    public CryptoCore(ObuParameters obuParameters, Cryptogram userCryptogram, Cryptogram receiverCryptogtam) {
        this.obuParameters = obuParameters;
        this.userCryptogram = userCryptogram;
        this.receiverCryptogram = receiverCryptogtam;
    }

    public byte[] getCiphertext() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        String userKey = hash(obuParameters.getDriverKey() + userCryptogram.getHatu(), "SHA-1"); //TODO: zkr8tit NA 128 BIT
        //String ukeyContent = userKey + "user" + userCryptogram.getNonce() + receiverCryptogram.getNonce();
        userKey= userKey.substring(0, 16);
        String ukeyString = hash(userKey + "user" + userCryptogram.getNonce() + receiverCryptogram.getNonce(),"SHA-1");
        ukeyString = ukeyString.substring(0,16);
        String plainTextString = userCryptogram.getHatu() + obuParameters.getIdr() + userCryptogram.getNonce() + receiverCryptogram.getNonce();
        //System.out.println(ukeyContent + " " + plainTextString);
        byte[] plainText = plainTextString.getBytes();
        //System.out.println("plaintext"+Arrays.toString(plainText));
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); // pořešit padding
        SecretKey ukey = new SecretKeySpec(ukeyString.getBytes(),"AES");
        GCMParameterSpec parameterSpec = new GCMParameterSpec(128, userCryptogram.getIv());
        cipher.init(Cipher.ENCRYPT_MODE, ukey, parameterSpec);
        byte[] cipherText = cipher.doFinal(plainText);
        cipherText = convertToPositiveBytes(cipherText);
        System.out.println("vypocitane"+Arrays.toString(cipherText));
        return cipherText;
    }

    public void c3andC4(byte[] ciphertext) throws NoSuchPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException, InvalidKeyException {
        String userKey = hash(obuParameters.getDriverKey() + userCryptogram.getHatu(), "SHA-1");
        String ukeyString = hash(userKey + "user" + userCryptogram.getNonce() + receiverCryptogram.getNonce(),"SHA-1");
        userKey= userKey.substring(0, 16);
        ukeyString = ukeyString.substring(0,16);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        SecretKey ukey = new SecretKeySpec(ukeyString.getBytes(),"AES");
        GCMParameterSpec parameterSpec = new GCMParameterSpec(128, userCryptogram.getIv());
        cipher.init(Cipher.DECRYPT_MODE,ukey, parameterSpec);
        //byte[] decryptedMessage = cipher.doFinal(ciphertext); //TODO: Tohle lze udelat az se vyresi problem s prenasenim negativnich bajtu
        byte[] ATU = Arrays.copyOfRange(ciphertext,0,32);
        //String message = new String(Arrays.copyOfRange(decryptedMessage,32,decryptedMessage.length));
        String message = "unlock";
        System.out.println("Message: " + message);
        String newHatu = hash(new String(ATU),"SHA-256");
        newHatu = newHatu.substring(0,16);
        if(newHatu.equals(userCryptogram.getHatu())){
            System.out.println("ATU akceptovano");
        }
        else System.out.println("ATU neakceptovano");
    }

    public static String hash(String input, String hashType)
    {
        try {
            // getInstance() method is called with algorithm SHA-1
            MessageDigest md = MessageDigest.getInstance(hashType);

            // digest() method is called
            // to calculate message digest of the input string
            // returned as array of byte
            byte[] messageDigest = md.digest(input.getBytes());

            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);

            // Add preceding 0s to make it 32 bit
            /*while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }*///

            // return the HashText
            return hashtext;
        }

        // For specifying wrong message digest algorithms
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public byte[] convertToPositiveBytes(byte[] bytes){
        byte[] byteArray = new byte[bytes.length];
        for(int i=0;i<bytes.length;i++){
            byteArray[i] = byteAbs(bytes[i]);
        }
        return byteArray;
    }

    byte byteAbs(byte b) {
        return b >= 0? b : (byte) (b == -128 ? 127 : -b);
    }

}
