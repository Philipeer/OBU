package org.bluez;

import org.freedesktop.dbus.DBusInterface;

public interface LEAdvertisement1 extends DBusInterface {
  public void Release();
}
