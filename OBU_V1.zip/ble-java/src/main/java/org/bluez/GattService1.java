package org.bluez;

import org.freedesktop.dbus.DBusInterface;

public interface GattService1 extends DBusInterface { }
