

import it.tangodev.ble.BleCharacteristic;
import it.tangodev.ble.BleService;
import it.tangodev.ble.BleCharacteristicListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.bluez.GattCharacteristic1;

public class NonceCharacteristic extends BleCharacteristic implements GattCharacteristic1 {

    Random rnd = new Random();

    //String exampleValue = String.valueOf(rnd.nextInt());
    String exampleValue = String.valueOf(1000);


    public NonceCharacteristic(BleService service) {
        super(service);
        List<CharacteristicFlag> flags = new ArrayList<CharacteristicFlag>();
        flags.add(CharacteristicFlag.READ);
        flags.add(CharacteristicFlag.WRITE);
        flags.add(CharacteristicFlag.NOTIFY);
        setFlags(flags);

        this.path = "/tango/s/ec";
        this.uuid = "c8ba0ef6-5c27-11ed-9b6a-0242ac120002";

        this.listener = new BleCharacteristicListener() {
            @Override
            public void setValue(byte[] value) {
                try {
                    exampleValue = new String(value, "UTF8");
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public byte[] getValue() {
                try {
                    return exampleValue.getBytes("UTF8");
                } catch(Exception e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }

}
