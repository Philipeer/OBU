import it.tangodev.ble.BleCharacteristic;
import it.tangodev.ble.BleCharacteristicListener;
import it.tangodev.ble.BleService;
import org.bluez.GattCharacteristic1;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CryptogramCharacteristic extends BleCharacteristic implements GattCharacteristic1 {

    Random rnd = new Random();

    String exampleValue = String.valueOf(rnd.nextInt());

    public CryptogramCharacteristic(BleService service) {
        super(service);
        List<CharacteristicFlag> flags = new ArrayList<CharacteristicFlag>();
        flags.add(CharacteristicFlag.READ);
        flags.add(CharacteristicFlag.WRITE);
        flags.add(CharacteristicFlag.NOTIFY);
        setFlags(flags);

        this.path = "/tango/s/er";
        this.uuid = "23cab78f-28d9-4ecb-bfd1-1bba7b486fa3";

        this.listener = new BleCharacteristicListener() {
            @Override
            public void setValue(byte[] value) {
                try {
                    exampleValue = new String(value, "UTF8");
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public byte[] getValue() {
                try {
                    return exampleValue.getBytes("UTF8");
                } catch(Exception e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }

}
