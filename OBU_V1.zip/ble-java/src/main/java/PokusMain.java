

import crypto.Client;
import crypto.CryptoCore;
import crypto.Cryptogram;
import it.tangodev.ble.BleApplication;
import it.tangodev.ble.BleApplicationListener;
import it.tangodev.ble.BleCharacteristic;
import it.tangodev.ble.BleCharacteristic.CharacteristicFlag;
import it.tangodev.ble.BleCharacteristicListener;
import it.tangodev.ble.BleService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.freedesktop.dbus.exceptions.DBusException;

public class PokusMain implements Runnable {

    protected String valueString = "Ciao ciao";
    BleApplication app;
    BleService service;
    BleCharacteristic nonceUserCharacteristic;
    NonceCharacteristic nonceReceiverCharacteristic;
    IdrCharacteristic idrCharacteristic;
    HatuCharacteristic hatuCharacteristic;
    IvCharacteristic ivCharacteristic;
    CryptogramCharacteristic cryptogramCharacteristic;

    public void notifyBle(String value) {
        this.valueString = value;
        nonceUserCharacteristic.sendNotification();
    }

    public PokusMain() throws DBusException, InterruptedException {
        BleApplicationListener appListener = new BleApplicationListener() {
            @Override
            public void deviceDisconnected() {
                System.out.println("Device disconnected");
            }

            @Override
            public void deviceConnected() {
                System.out.println("Device connected");
            }
        };
        app = new BleApplication("/tango", appListener);
        service = new BleService("/tango/s", "18b41747-01df-44d1-bc25-187082eb76bf", true);
        List<CharacteristicFlag> flags = new ArrayList<CharacteristicFlag>();
        flags.add(CharacteristicFlag.READ);
        flags.add(CharacteristicFlag.WRITE);
        flags.add(CharacteristicFlag.NOTIFY);

        nonceUserCharacteristic = new BleCharacteristic("/tango/s/c", service, flags, "bc3ba145-f588-4f86-8bc4-fb925a23dc31", new BleCharacteristicListener() {
            @Override
            public void setValue(byte[] value) {
                try {
                    valueString = new String(value, "UTF8");
                } catch(Exception e) {
                    System.out.println("");
                }
            }

            @Override
            public byte[] getValue() {
                try {
                    return valueString.getBytes("UTF8");
                } catch(Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        service.addCharacteristic(nonceUserCharacteristic);
        app.addService(service);

        nonceReceiverCharacteristic = new NonceCharacteristic(service);
        hatuCharacteristic = new HatuCharacteristic(service);
        idrCharacteristic = new IdrCharacteristic(service);
        ivCharacteristic = new IvCharacteristic(service);
        cryptogramCharacteristic = new CryptogramCharacteristic(service);


        service.addCharacteristic(nonceReceiverCharacteristic);
        service.addCharacteristic(hatuCharacteristic);
        service.addCharacteristic(idrCharacteristic);
        service.addCharacteristic(ivCharacteristic);
        service.addCharacteristic(cryptogramCharacteristic);
        app.start();
    }

    @Override
    public void run() {
        try {
            this.wait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public BleApplication getApp() {
        return app;
    }

    public static void main(String[] args) throws Exception {
        PokusMain example = new PokusMain();
        System.out.println("");
        Client client = new Client();
        Cryptogram userCryptogram = new Cryptogram();
        Cryptogram receiverCryptogram = new Cryptogram();

        example.idrCharacteristic.exampleValue = String.valueOf(client.obuParameters.getIdr());


        Thread t = new Thread(example);
        t.start();
        System.out.println(example.service.getCharacteristics().toString());
        Thread.sleep(30000);
        System.out.println("Starting notfying");
        //example.notifyBle("woooooo");
        example.service.getCharacteristics().get(0).sendNotification();
        Thread.sleep(10000);
        Thread.sleep(10000);
        Thread.sleep(10000);
        Thread.sleep(10000);
        Thread.sleep(10000);

        System.out.println("-------------------------");
        System.out.println("OBU hodnoty:");
        System.out.println("Nr: " + example.nonceReceiverCharacteristic.exampleValue);
        int nr = Integer.parseInt(example.nonceReceiverCharacteristic.exampleValue);
        receiverCryptogram.setNonce(nr);
        System.out.println("IDr: " + example.idrCharacteristic.exampleValue);
        System.out.println("-------------------------");
        System.out.println("Obdrzeno od Appky:");
        int nu = Integer.parseInt(example.valueString);
        System.out.println("Nu: " + nu);
        System.out.println("HATu: " + example.hatuCharacteristic.exampleValue);
        userCryptogram.setNonce(nu);
        userCryptogram.setHatu(example.hatuCharacteristic.exampleValue);
        userCryptogram.setIv(example.ivCharacteristic.exampleValue.getBytes());
        System.out.println("IV: " + Arrays.toString(example.ivCharacteristic.exampleValue.getBytes()));
        System.out.println("-------------------------");
        CryptoCore cryptoCore = new CryptoCore(client.obuParameters,userCryptogram,receiverCryptogram);
        byte[] c1 = example.cryptogramCharacteristic.exampleValue.getBytes();
        //System.out.println("prijmute: " + Arrays.toString(c1));
        if(Arrays.equals(cryptoCore.getCiphertext(),c1)){
            System.out.println("Autentizovano");
        }
        else System.out.println("Neautentizovano");

        //C2
        example.cryptogramCharacteristic.exampleValue = "true";
        example.cryptogramCharacteristic.sendNotification();
        example.cryptogramCharacteristic.exampleValue = null;
        //example.notifyBle("NRtrue");
        Thread.sleep(10000);

        //C3
        Thread.sleep(15000);

        //System.out.println(Arrays.toString(example.cryptogramCharacteristic.exampleValue.getBytes()));
        cryptoCore.c3andC4(example.cryptogramCharacteristic.exampleValue.getBytes());
        example.cryptogramCharacteristic.exampleValue = "true";
        example.cryptogramCharacteristic.sendNotification();

//		Thread.sleep(15000);
//		t.notify();

//		Thread.sleep(5000);
//		System.out.println("stopping application");
        example.getApp().stop();
        System.out.println("Application stopped");
    }

}
