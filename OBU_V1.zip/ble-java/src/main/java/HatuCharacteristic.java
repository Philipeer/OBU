import it.tangodev.ble.BleCharacteristic;
import it.tangodev.ble.BleCharacteristicListener;
import it.tangodev.ble.BleService;
import org.bluez.GattCharacteristic1;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HatuCharacteristic extends BleCharacteristic implements GattCharacteristic1 {

    Random rnd = new Random();

    String exampleValue = String.valueOf(rnd.nextInt());

    public HatuCharacteristic(BleService service) {
        super(service);
        List<CharacteristicFlag> flags = new ArrayList<CharacteristicFlag>();
        flags.add(CharacteristicFlag.READ);
        flags.add(CharacteristicFlag.WRITE);
        flags.add(CharacteristicFlag.NOTIFY);
        setFlags(flags);

        this.path = "/tango/s/eh";
        this.uuid = "b828f7a3-157a-4a4e-9c9b-3feb19b8e90d";

        this.listener = new BleCharacteristicListener() {
            @Override
            public void setValue(byte[] value) {
                try {
                    exampleValue = new String(value, "UTF8");
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public byte[] getValue() {
                try {
                    return exampleValue.getBytes("UTF8");
                } catch(Exception e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }

}
