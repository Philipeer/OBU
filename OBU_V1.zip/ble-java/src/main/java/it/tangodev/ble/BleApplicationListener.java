package it.tangodev.ble;

public interface BleApplicationListener {
	public void deviceConnected();
	public void deviceDisconnected();
}
