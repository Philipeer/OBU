import it.tangodev.ble.BleCharacteristic;
import it.tangodev.ble.BleCharacteristicListener;
import it.tangodev.ble.BleService;
import org.bluez.GattCharacteristic1;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class IdrCharacteristic extends BleCharacteristic implements GattCharacteristic1 {


    String exampleValue;

    public IdrCharacteristic(BleService service) {
        super(service);
        List<CharacteristicFlag> flags = new ArrayList<CharacteristicFlag>();
        flags.add(CharacteristicFlag.READ);
        flags.add(CharacteristicFlag.WRITE);
        flags.add(CharacteristicFlag.NOTIFY);
        setFlags(flags);

        this.path = "/tango/s/ei";
        this.uuid = "01e6ee2d-420a-4380-8e14-2a83844d4ae8";

        this.listener = new BleCharacteristicListener() {
            @Override
            public void setValue(byte[] value) {
                try {
                    exampleValue = new String(value, "UTF8");
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public byte[] getValue() {
                try {
                    return exampleValue.getBytes("UTF8");
                } catch(Exception e) {
                    throw new RuntimeException(e);
                }
            }
        };
    }

}
